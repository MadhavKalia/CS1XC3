/**
 * @file student.c
 * @author Madhav Kalia
 * @brief Creates the functions for student
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief adds the grade to the student's list
 * 
 * @param student the student to add the grades to
 * @param grade the grade to add to the list
 * @return Nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  //If there is only one grade then it dynamically allocates memory to store one grade using calloc
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  //If there is more than one grade then it dynamiacally allocates more memory using realloc to store all the grades
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Calculates the student's average 
 * 
 * @param student the student to calculate the average for
 * @return double - the average of the student
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;

  //Loops through all the grades of the student and sums them
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  
  //Returns the sum of the grade divided by the number of grades
  return total / ((double) student->num_grades);
}

/**
 * @brief prints the information of the student
 * 
 * @param student the student to print the information of 
 * @return Nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");

  //Loops through all the grades to print them
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Creates the random student
 * 
 * @param grades the number grades to give 
 * @return Student* - the random student created
 */
Student* generate_random_student(int grades)
{
  //First names to pick from
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  //Last names to pick from
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  //Dynamically allocates memory for the student using calloc
  Student *new_student = calloc(1, sizeof(Student));

  //Sets the student's first and last name to a random name from the lists
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //Loop used to generate a random ID to give to the student
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //Loop used to generate a random grade to give to the student
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}