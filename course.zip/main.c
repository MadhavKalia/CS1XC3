/**
 * @file main.c
 * @author Madhav Kalia
 * @brief code demonstrates the other libraries in the folder 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief creates course MATH101 and enrolls random number of  students into the course
 * uses functions in the libraries to print information about the students
 *
 * @return int 
 */
int main()
{
  //Initializes random number generator used in the code
  srand((unsigned) time(NULL));

  //Creates pointer type course using calloc 
  Course *MATH101 = calloc(1, sizeof(Course));

  //Sets the name and code of course
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //Enrolls random number of students in course created
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //Uses functions in libraries to print student with highest mark
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //Uses functions in libraries to print students are that passing 
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}