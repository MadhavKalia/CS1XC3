/**
 * @file course.c
 * @author Madhav Kalia
 * @brief Creates the functions for course
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief enrolls the student in the course
 * 
 * @param course the course to enroll the student into
 * @param student the student to enroll
 * @return Nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;

  //If there is only one student to enroll then it dynamically allocates memory for only one student using calloc
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }

  //If there is more than student then it reallocates the memory each time using realloc to store all the students
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief prints all the information about the course
 * 
 * @param course the course to print
 * @return Nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //uses for loop to print all the students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief finds the student with the highest average in the course
 * 
 * @param course the course to find the top student
 * @return Student*  the student with the highest average
 */
Student* top_student(Course* course)
{

  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //Loops through the students in the course and finds the one with the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief finds all the students in the course that are passing 
 * 
 * @param course the course to find the students
 * @param total_passing  the total number of students passing 
 * @return Student* the students passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //Loops through each students mark to count how many passing students there are
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //dynamically allocates memory based on number of passing students 
  passing = calloc(count, sizeof(Student));

  int j = 0;

  //Loops through each students mark and stores the passing student in the array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  //pointer variable is set to the number of passing students 
  *total_passing = count;

  return passing;
}